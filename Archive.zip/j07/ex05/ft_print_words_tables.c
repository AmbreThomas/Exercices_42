/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_words_tables.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/14 14:33:57 by athomas           #+#    #+#             */
/*   Updated: 2016/07/14 21:10:48 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

char	**ft_split_whitespaces(char *str);
void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putstr(char *str)
{
	int		i;
	char	temp;

	i = 0;
	temp = str[i];
	while (temp)
	{
		ft_putchar(temp);
		i++;
		temp = str[i];
	}
}

void	ft_print_words_tables(char **tab)
{
	int		i;

	i = 0;
	while (tab[i])
	{
		ft_putstr(tab[i]);
		ft_putchar('\n');
		i++;
	}
}

int		main(void)
{
	char **tab;

	tab = ft_split_whitespaces("Yo   je sais  pas si ca gere quand  y a plein despace");
	ft_print_words_tables(tab);
	return (0);
}
