/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert_base.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/14 19:16:17 by athomas           #+#    #+#             */
/*   Updated: 2016/07/14 19:43:40 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

char *ft_convert_base(char *nbr, char *base_from, char *base_to)
{
	char *retour;


	return (retour);
}

int		main(void)
{
	char *str;

	str = ft_convert_base("16", "0123456789", "0123456789ABCDEF");
	printf("%s\n", str);
	return (0);
}
