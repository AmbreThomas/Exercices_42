/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_concat_params.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/13 14:05:50 by athomas           #+#    #+#             */
/*   Updated: 2016/07/14 09:56:54 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		ft_strlen(char *str)
{
	int		i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

char	*ft_strcat(char *dest, char *src)
{
	int i;
	int j;

	i = 0;
	while (dest[i])
		i++;
	j = 0;
	while (src[j])
	{
		dest[i] = src[j];
		i++;
		j++;
	}
	dest[i] = '\0';
	return (dest);
}

char	*ft_concat_params(int argc, char **argv)
{
	int		size;
	int		i;
	char	*res;

	if (argc <= 1)
		return (res = "");
	size = 0;
	i = 1;
	while (argv[i])
		size += ft_strlen(argv[i++]);
	size += (argc - 1) * 2;
	res = (char*)malloc(size);
	i = 1;
	ft_strcat(res, argv[i]);
	i++;
	while (argv[i])
	{
		ft_strcat(res, "\n");
		ft_strcat(res, argv[i]);
		i++;
	}
	res[size] = '\0';
	return (res);
}
