/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split_whitespaces.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/13 17:49:09 by athomas           #+#    #+#             */
/*   Updated: 2016/07/14 17:46:05 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		count_words(char *str)
{
	int i;
	int size;
	int compteur;

	size = 0;
	i = 0;
	while (str[i])
	{
		compteur = 0;
		while (str[i] != '\n' && str[i] != '\t' && str[i] != ' ')
		{
			i++;
			compteur++;
		}
		if (compteur > 0)
			size++;
		i++;
	}
	return (size);
}


int		count_lenwords(char *str, int i)
{
	int size;

	size = 0;
	while (str[i] && str[i] != '\n' && str[i] != '\t' && str[i] != ' ')
	{
		size++;
		i++;
	}
	return (size);
}

char	**ft_split_whitespaces(char *str)
{
	char	**mots;
	int		j;
	int		i;
	int		t;
	int		taille;

	mots = (char**)malloc(sizeof(**mots) * (count_words(str) + 1));
	i = 0;
	t = 0;
	while (str[i])
	{
		if (str[i] != '\n' && str[i] != '\t' && str[i] != ' ')
		{
			j = 0;
			taille = count_lenwords(str, i);
			mots[t] = (char*)malloc(sizeof(*mots) * (taille));
			while (j < taille)
				mots[t][j++] = str[i++];
			mots[t++][j] = '\0';
		}
		i++;
	}
	mots[t] = 0;
	return (mots);
}
