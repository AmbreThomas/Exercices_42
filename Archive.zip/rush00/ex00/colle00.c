/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   colle00.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/09 14:34:38 by athomas           #+#    #+#             */
/*   Updated: 2016/07/13 11:26:56 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_putchar(char c);
void	ft_print_corner(int i);
void	ft_print_lignes(int i, int j);
void	ft_print_colonnes(int i);
void	ft_print_lignes2(int i, int j);

void	colle(int x, int y)
{
	if (x <= 0 || y <= 0)
		return ;
	if (x >= 1 && y == 1)
	{
		ft_print_lignes(x - 2, 0);
		if (x == 1 || y == 1)
		{
			ft_putchar('\n');
			return ;
		}
	}
	if (y >= 1 && x == 1)
	{
		ft_print_corner(1);
		ft_print_colonnes(y - 2);
		ft_print_corner(3);
		ft_putchar('\n');
	}
	if (y > 1 && x > 1)
	{
		ft_print_lignes(x - 2, 1);
		ft_print_lignes2(x - 2, y - 2);
		ft_print_lignes(x - 2, 2);
	}
}

void	ft_print_corner(int i)
{
	if (i == 1)
		ft_putchar('o');
	if (i == 2)
	{
		ft_putchar('o');
		ft_putchar('\n');
	}
	if (i == 3)
		ft_putchar('o');
	if (i == 4)
	{
		ft_putchar('o');
		ft_putchar('\n');
	}
}

void	ft_print_lignes(int i, int j)
{
	if (j == 0 || j == 1)
		ft_print_corner(1);
	if (j == 2)
		ft_print_corner(3);
	while (i > 0)
	{
		ft_putchar('-');
		i--;
	}
	if (j == 0 && i != -1)
		ft_print_corner(3);
	if (j == 1)
		ft_print_corner(2);
	if (j == 2)
		ft_print_corner(4);
}

void	ft_print_colonnes(int i)
{
	if (i == 0)
		return ;
	ft_putchar('\n');
	while (i > 0)
	{
		ft_putchar('|');
		ft_putchar('\n');
		i--;
	}
}

void	ft_print_lignes2(int i, int j)
{
	int tempi;

	tempi = i;
	while (j > 0)
	{
		i = tempi;
		ft_putchar('|');
		while (i > 0)
		{
			ft_putchar(' ');
			i--;
		}
		ft_putchar('|');
		ft_putchar('\n');
		j--;
	}
}
