/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_params.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/12 14:06:57 by athomas           #+#    #+#             */
/*   Updated: 2016/07/13 09:27:09 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

int		main(int argc, char **argv)
{
	int		i;
	int		j;
	char	*nom;

	i = argc - 1;
	while (i > 0)
	{
		j = 0;
		nom = argv[i];
		while (nom[j])
		{
			ft_putchar(nom[j]);
			j++;
		}
		ft_putchar('\n');
		i--;
	}
	return (0);
}
