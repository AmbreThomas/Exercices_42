/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_program_name.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/12 12:55:50 by athomas           #+#    #+#             */
/*   Updated: 2016/07/13 10:38:27 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

int		main(int argc, char **argv)
{
	char	*nom;
	int		i;

	(void)argc;
	nom = argv[0];
	i = 0;
	while (nom[i])
	{
		ft_putchar(nom[i]);
		i++;
	}
	return (0);
}
