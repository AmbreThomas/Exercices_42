/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   union.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/21 23:14:53 by athomas           #+#    #+#             */
/*   Updated: 2016/07/21 23:45:43 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

int		ft_strlen(char *str)
{
	int i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

void	afficher_union(char *s1, char *s2)
{
	int taille1 = ft_strlen(s1);
	int taille2 = ft_strlen(s2);
	int i = 0;
	int j = 0;
	int compteur;
	while (i < taille1)
	{
		j = i - 1;
		compteur = 0;
		while (j >= 0)
		{
			if (s1[i] == s1[j])
				compteur++;
			j--;
		}
		if (compteur == 0)
			ft_putchar(s1[i]);
		i++;
	}
	i = 0;
	while (i < taille2)
	{
		j = 0;
		compteur = 0;
		while (s1[j])
		{
			if(s2[i] == s1[j])
				compteur++;
			j++;
		}
		j = i - 1;
		while (j >= 0)
		{
			if (s2[j] == s2[i])
				compteur++;
			j--;
		}
		if (compteur == 0)
			ft_putchar(s2[i]);
		i++;
	}
}

int		main(int ac, char **av)
{
	if (ac != 3)
		return (0);
	else
		afficher_union(av[1], av[2]);
	return (0);
}
