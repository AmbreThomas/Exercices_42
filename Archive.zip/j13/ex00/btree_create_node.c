/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   btree_create_node.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/21 14:17:53 by athomas           #+#    #+#             */
/*   Updated: 2016/07/22 08:51:16 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_btree.h"
#include <stdlib.h>

t_btree	*btree_create_node(void *item)
{
	t_btree *elem;

	elem = NULL;
	if ((elem = (t_btree*)malloc(sizeof(t_btree))) == NULL)
		return (0);
	if (elem)
	{
		elem->item = item;
		elem->right = 0;
		elem->left = 0;
	}
	return (elem);
}
