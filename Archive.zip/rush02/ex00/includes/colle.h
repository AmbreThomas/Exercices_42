/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   colle.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/24 11:04:34 by athomas           #+#    #+#             */
/*   Updated: 2016/07/24 18:06:20 by elopvet          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef COLLE_H
# define COLLE_H

typedef struct		s_ligne
{
	char	carac1;
	char	carac2;
	char	carac3;
}					t_ligne;

void				ft_strcat(char *dest, char *src);
void				ft_fill_dest(int x, char *dest, t_ligne **ligne);
void				compare_colle(char *colle, int x, int y);
void				ft_putstr(char *str);
void				ft_putchar(char c);
void				ft_putnbr(int nb);
int					ft_strcmp(char *s1, char *s2);
char				**colle00(int x, int y);
char				**colle01(int x, int y);
char				**colle02(int x, int y);
char				**colle03(int x, int y);
char				**colle04(int x, int y);
void				ft_argtostr(char **str);
void				ft_strcpy(char *dest, char *src);
void				ft_findxy(char *str, int *x, int *y);

#endif
