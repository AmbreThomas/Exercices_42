/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/24 10:06:16 by athomas           #+#    #+#             */
/*   Updated: 2016/07/24 19:29:31 by elopvet          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "colle.h"

int		main(void)
{
	char	**colle;
	char	*str;
	int		y;
	int		x;

	x = 0;
	y = 0;
	str = (char *)malloc(sizeof(char));
	colle = &str;
	*str = '\0';
	ft_argtostr(colle);
	ft_findxy(*colle, &x, &y);
	if (y != 0)
		x = x / y;
	compare_colle(*colle, x, y);
	free(*colle);
	return (0);
}
