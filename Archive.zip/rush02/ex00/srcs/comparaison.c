/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   comparaison.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/24 10:06:16 by athomas           #+#    #+#             */
/*   Updated: 2016/07/24 19:29:01 by elopvet          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include "colle.h"

void	ft_print_success(int verif, char *c, int x, int y)
{
	if (verif == 0)
	{
		write(1, " || ", 4);
	}
	write(1, "[colle-0", 8);
	ft_putstr(c);
	write(1, "] [", 3);
	ft_putnbr(x);
	write(1, "] [", 3);
	ft_putnbr(y);
	write(1, "]", 1);
}

void	next(int verif, char *colle, int x, int y)
{
	if (ft_strcmp(colle, *colle04(x, y)) == 0)
	{
		ft_print_success(verif, "4", x, y);
		verif = 0;
	}
	if (verif != 0)
		write(1, "aucune", 6);
	write(1, "\n", 1);
}

void	compare_colle(char *colle, int x, int y)
{
	int verif;

	verif = -1;
	if (ft_strcmp(colle, *colle00(x, y)) == 0)
	{
		ft_print_success(verif, "0", x, y);
		verif = 0;
	}
	if (ft_strcmp(colle, *colle01(x, y)) == 0)
	{
		ft_print_success(verif, "1", x, y);
		verif = 0;
	}
	if (ft_strcmp(colle, *colle02(x, y)) == 0)
	{
		ft_print_success(verif, "2", x, y);
		verif = 0;
	}
	if (ft_strcmp(colle, *colle03(x, y)) == 0)
	{
		ft_print_success(verif, "3", x, y);
		verif = 0;
	}
	next(verif, colle, x, y);
}
