/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tools.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eduwer <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/24 11:47:42 by eduwer            #+#    #+#             */
/*   Updated: 2016/07/24 17:53:43 by elopvet          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "colle.h"

int		ft_strcmp(char *s1, char *s2)
{
	int		i;

	i = 0;
	while (s1[i] != '\0' && s2[i] != '\0' && s1[i] == s2[i])
		i++;
	return (s1[i] - s2[i]);
}

void	ft_strcat(char *dest, char *src)
{
	int		i;
	int		j;

	i = 0;
	j = 0;
	while (dest[i])
		i++;
	while (src[j])
	{
		dest[i + j] = src[j];
		j++;
	}
	dest[i + j] = '\0';
}

void	ft_strcpy(char *dest, char *src)
{
	int		i;

	i = 0;
	if (dest && src)
	{
		while (src[i])
		{
			dest[i] = src[i];
			i++;
		}
		dest[i] = '\0';
	}
}

void	ft_fill_dest(int x, char *dest, t_ligne **ligne)
{
	int		i;
	char	*src;

	i = 1;
	src = (char *)malloc(sizeof(char) * (x + 2));
	src[0] = (*ligne)->carac1;
	while (i < (x - 1))
	{
		src[i] = (*ligne)->carac2;
		i++;
	}
	if (x > 1)
	{
		src[i] = (*ligne)->carac3;
		i++;
	}
	src[i] = '\n';
	i++;
	src[i] = '\0';
	ft_strcat(dest, src);
	free(src);
}
