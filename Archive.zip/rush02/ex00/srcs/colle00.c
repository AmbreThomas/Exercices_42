/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   colle00.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: elopvet <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/10 12:19:43 by elopvet           #+#    #+#             */
/*   Updated: 2016/07/24 19:13:35 by elopvet          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "colle.h"

void	ft_strcat_c0(char *dest, char *src)
{
	int		i;
	int		j;

	i = 0;
	j = 0;
	while (dest[i])
		i++;
	while (src[j])
	{
		dest[i + j] = src[j];
		j++;
	}
	dest[i + j] = '\0';
}

void	ft_fill_dest_c0(int x, char *dest, t_ligne **ligne)
{
	int		i;
	char	*src;

	i = 1;
	src = (char *)malloc(sizeof(char) * (x + 2));
	src[0] = (*ligne)->carac1;
	while (i < (x - 1))
	{
		src[i] = (*ligne)->carac2;
		i++;
	}
	if (x > 1)
	{
		src[i] = (*ligne)->carac3;
		i++;
	}
	src[i] = '\n';
	i++;
	src[i] = '\0';
	ft_strcat_c0(dest, src);
	free(src);
}

void	ft_fill_struct_c0(t_ligne **ligne1, t_ligne **ligne2, t_ligne **ligne3)
{
	*ligne1 = (t_ligne *)malloc(sizeof(t_ligne));
	*ligne2 = (t_ligne *)malloc(sizeof(t_ligne));
	*ligne3 = (t_ligne *)malloc(sizeof(t_ligne));
	(*ligne1)->carac1 = 'o';
	(*ligne1)->carac2 = '-';
	(*ligne1)->carac3 = 'o';
	(*ligne2)->carac1 = '|';
	(*ligne2)->carac2 = ' ';
	(*ligne2)->carac3 = '|';
	(*ligne3)->carac1 = 'o';
	(*ligne3)->carac2 = '-';
	(*ligne3)->carac3 = 'o';
}

void	ft_process_c0(char *dest, int x, int y)
{
	int			i;
	t_ligne		*ligne1;
	t_ligne		*ligne2;
	t_ligne		*ligne3;

	i = 1;
	ligne1 = 0;
	ligne2 = 0;
	ligne3 = 0;
	ft_fill_struct_c0(&ligne1, &ligne2, &ligne3);
	ft_fill_dest_c0(x, dest, &ligne1);
	free(ligne1);
	while (i++ < (y - 1))
		ft_fill_dest_c0(x, dest, &ligne2);
	free(ligne2);
	if (y > 1)
		ft_fill_dest_c0(x, dest, &ligne3);
	free(ligne3);
}

char	**colle00(int x, int y)
{
	char		*dest;
	char		**ptr;
	char		empty;

	dest = 0;
	empty = '\0';
	if (x > 0 && y > 0)
	{
		dest = (char *)malloc(sizeof(char) * (((x + 1) * y) + 1));
		dest[0] = '\0';
		ft_process_c0(dest, x, y);
	}
	else
		dest = &empty;
	ptr = &dest;
	return (ptr);
}
