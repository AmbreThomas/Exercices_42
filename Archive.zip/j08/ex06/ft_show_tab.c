/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_show_tab.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/14 17:00:23 by athomas           #+#    #+#             */
/*   Updated: 2016/07/14 18:50:09 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_stock_par.h"
#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putstr(char *str)
{
	int		i;

	i = 0;
	while (str[i])
		ft_putchar(str[i++]);
}

void	ft_putnbr(int nb)
{
	if (nb == -2147483648)
		ft_putstr("-2147483648");
	else
	{
		if (nb < 0)
		{
			ft_putchar('-');
			nb = nb * -1;
		}
		if (nb >= 10)
		{
			ft_putnbr(nb / 10);
		}
		ft_putchar(nb % 10 + '0');
	}
}

void	ft_show_tab(struct s_stock_par *par)
{
	int i;
	int j;

	i = 0;
	while (par->str[i])
		ft_putchar(par->str[i++]);
	ft_putchar('\n');
	ft_putnbr(par->size_param);
	ft_putchar('\n');
	i = 0;
	while (par->tab[i])
	{
		while (par->tab[i][j])
			ft_putchar(par->tab[i][j++]);
		ft_putchar('\n');
		i++;
	}
}

int		main(int ac, char **av)
{
	t_stock_par *tab;

	tab = ft_param_to_tab(ac, av);
	ft_show_tab(tab);
	return (0);
}
