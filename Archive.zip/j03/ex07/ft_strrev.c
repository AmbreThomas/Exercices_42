/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrev.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/07 19:28:56 by athomas           #+#    #+#             */
/*   Updated: 2016/07/12 16:55:31 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

char	*ft_strrev(char *str);

int		ft_strlen(char *str)
{
	int		i;
	char	temp;

	i = 0;
	temp = str[i];
	while (temp)
	{
		i++;
		temp = str[i];
	}
	return (i);
}

char	*ft_strrev(char *str)
{
	int		i;
	int		compteur;
	char	temp[ft_strlen(str)];

	i = ft_strlen(str) - 1;
	compteur = 0;
	while (i >= 0)
	{
		temp[compteur] = str[i];
		i--;
		compteur++;
	}
	compteur = 0;
	while (compteur < ft_strlen(str))
	{
		str[compteur] = temp[compteur];
		compteur++;
	}
	return (str);
}
