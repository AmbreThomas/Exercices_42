/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/08 10:20:19 by athomas           #+#    #+#             */
/*   Updated: 2016/07/08 11:05:19 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int ft_atoi(char *str);

int		ft_putchar(char c)
{
	write(1, &c, 1);
	return(0);
}

void	ft_putnbr(int nb)
{
	if (nb < 0)
	{
		ft_putchar('-');
		nb = nb * -1;
	}
	if (nb > 9)
	{
		ft_putnbr(nb / 10);
	}
	ft_putchar((nb % 10) + '0');
}

int		ft_strlen(char *str)
{
	int		i;
	char	temp;

	i = 0;
	temp = str[i];
	while (temp)
	{
		i++;
		temp = str[i];
	}
	return (i);
}

int		ft_lol(char *str)
{
	int		i;
	int compteur;

	compteur = 0;
	i = ft_strlen(str) - 1;
	while (i >= 0)
	{
		if (str[i] < 58 && str[i] > 47)
		{
			compteur ++;
		}
		else
			return (compteur);
		i--;
	}
	return (compteur);
}

int		ft_atoi(char *str)
{
	int		i;
	char	temp[ft_lol(str)];
	int		compteur;
	int		res;

	i = 0;
	compteur = ft_lol(str);
	while  (i < compteur)
	{
		temp[i] = str[i];
		i--;
	}
	res = (int)temp;
	return (res);
}

int		main(void)
{
	ft_putnbr(ft_atoi("243a"));
	return (0);
}
