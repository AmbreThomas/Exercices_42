/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_spy.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/15 11:08:34 by athomas           #+#    #+#             */
/*   Updated: 2016/07/15 12:16:57 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

int		Check_president(char *str, int i)
{
	char *president;

	president = "president";
	if (str[i] == president[i])
		return (1);
	return (0);
}

int		Check_attack(char *str, int i)
{
	char *attack;

	attack = "attack";
	if (str[i] == attack[i])
		return (1);
	return (0);
}

int		Check_Powers(char *str, int i)
{
	char *powers;

	powers = "Powers";
	if (str[i] == powers[i])
		return (1);
	return (0);
}

int		ft_alert(char *str)
{
	int i;
	int j;
	int verif1;
	int verif2;
	int verif3;

	i = 0;
	j = 0;
	while (str[i] && (verif1 || verif2 || verif3) && str[i] > ' ')
	{
		verif1 = Check_president(str, j);
		verif2 = Check_attack(str, j);
		verif3 = Check_Powers(str, j);
		if (str[i] > ' ')
			j++;
		i++;
	}
	if (verif1 || verif3 || verif2)
		return (1);
	else
		return (0);
}

int		main(int argc, char **argv)
{
	(void)argc;
	int i;
	int alert;
	int j;

	if (argc <= 1)
		return (0);
	i = 1;
	while (argv[i])
		alert = ft_alert(argv[i++]);
	i = 0;
	if (alert == 0)
		return (0);
	if (alert)
	{
		ft_putchar('A');
		ft_putchar('l');
		ft_putchar('e');
		ft_putchar('r');
		ft_putchar('t');
		ft_putchar('!');
		ft_putchar('!');
		ft_putchar('!');
		ft_putchar('\n');
	}
	return (0);
}
