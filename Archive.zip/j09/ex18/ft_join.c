/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_join.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/15 14:47:06 by athomas           #+#    #+#             */
/*   Updated: 2016/07/15 15:14:35 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

char	*ft_join(char **tab, char *sep)
{
	char *str;
	int i;
	int j;
	int size;

	i = 0;
	while (tab[i])
	{
		j = 0;
		while (tab[i][j++])
			size++;
		i++;
	}
	str = (char*)malloc(sizeof(*str) * (size + 1));
	i = 0;
	size = 0;
	while (tab[i])
	{
		j = 0;
		while (tab[i][j])
			str[size++] = tab[i][j++];
		j = 0;
		while (sep[j])
			str[size++] = sep[j++];
		i++;
	}
	str[size] = '\0';
	return (str);
}
