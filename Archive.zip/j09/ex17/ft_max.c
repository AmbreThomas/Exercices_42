/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_max.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/15 14:28:23 by athomas           #+#    #+#             */
/*   Updated: 2016/07/15 14:45:31 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_max(int *tab, int length)
{
	int i;
	int stock;

	i = 0;
	if (length == 0)
		return (0);
	stock = tab[i];
	while (tab[i])
	{
		if (tab[i] > stock)
			stock = tab[i];
		i++;
	}
	return (stock);
}
