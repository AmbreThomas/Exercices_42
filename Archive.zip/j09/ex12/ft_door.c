/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_door.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/15 12:41:45 by athomas           #+#    #+#             */
/*   Updated: 2016/07/15 14:11:13 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_door.h"

void	ft_putstr(char *str)
{
	int		i;
	char	c;

	i = 0;
	while (str[i])
	{
		c = str[i++];
		write(1, &c, 1);
	}
}

void	open_door(t_door *door)
{
	ft_putstr("Door opening...\n");
	door->state = 1;
}

void	close_door(t_door *door)
{
	ft_putstr("Door closing...\n");
	door->state = 0;
}

int		is_door_open(t_door *door)
{
	ft_putstr("Door is open ?\n");
	if (door->state)
		return (door->state);
	return (0);
}

int		is_door_close(t_door *door)
{
	ft_putstr("Door is close ?\n");
	if (door->state == 0)
		return (1);
	return (0);
}
