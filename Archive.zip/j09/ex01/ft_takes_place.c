/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_takes_place.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/14 18:50:35 by athomas           #+#    #+#             */
/*   Updated: 2016/07/15 09:52:10 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_takes_place(int hour)
{
	if (hour == 24)
	{
		printf("THE FOLLOWING TAKES PLACE BETWEEN 12.00 A.M. AND 01.00 A.M.\n");
		return ;
	}
	printf("THE FOLLOWING TAKES PLACE BETWEEN ");
	if (hour < 12)
		printf("%i.00 A.M. AND ", hour);
	if (hour > 12)
		printf("%i.00 P.M. AND ", hour - 12);
	if (hour == 12)
		printf("12.00 P.M. AND ");
	if (hour + 1 < 12)
		printf("%i.00 A.M.", hour + 1);
	if (hour + 1 == 24)
		printf("%i.00 A.M.", 12);
	else if (hour + 1 > 12)
		printf("%i.00 P.M.", hour + 1 - 12);
	if (hour + 1 == 12)
		printf("12.00 P.M.");
	printf("\n");
}
