/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_unmatch.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/15 15:15:36 by athomas           #+#    #+#             */
/*   Updated: 2016/07/15 15:24:45 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_unmatch(int *tab, int length)
{
	int temp;
	int i;
	int j;

	i = 0;
	while (tab[i])
	{
		i = j;
		temp = tab[i];
		while (tab[i++])
		{
			if (tab[i] == temp)
			{
				if (tab[++j] == temp)
					j += 2;
				else
					j++;
			}
		}
		i++;
	}
	return (temp);
}
