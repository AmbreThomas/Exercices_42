/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimator.h                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/15 10:22:56 by athomas           #+#    #+#             */
/*   Updated: 2016/07/15 10:23:06 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef __FT_ULTIMATOR_H__
# define __FT_ULTIMATOR_H__
/*
 * **
 * ** Avec Windows VISTA, on etait au bord du precipice.
 * ** Avec Windows 8, on a fait un grand pas en avant
 * **
 * ** Le Client: 'J'ai un PC avec Windows 8'
 * ** Le Technicien: 'Oui...'
 * ** Le Client: 'Et puis mon PC ne marche plus'
 * ** Le Technicien: 'Oui, vous me l'avez deja dit'...
 * **
 * */
#endif
