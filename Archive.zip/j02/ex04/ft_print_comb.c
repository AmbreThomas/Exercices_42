/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/06 17:08:04 by athomas           #+#    #+#             */
/*   Updated: 2016/07/20 05:06:20 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int		ft_putchar(char c);
void	ft_print_comb(void);
void	ft_print_combsuite(int i, int j, int k);
void	ft_print(int x, int y, int z);

void	ft_print_comb(void)
{
	int k;
	int i;
	int j;

	i = 48;
	j = 49;
	k = 50;
	ft_putchar(i);
	ft_putchar(j);
	ft_putchar(k);
	ft_print_combsuite(i, j, k);
}

void	ft_print_combsuite(int i, int j, int k)
{
	while (1)
	{
		i = 48;
		while (i <= 55)
		{
			j = i + 1;
			while (j <= 56)
			{
				k = j + 1;
				if (k == 50)
					k = 51;
				while (k <= 57)
				{
					ft_print(i, j, k);
					if (i == 55 && j == 56 && k == 57)
						return ;
					k++;
				}
				j++;
			}
			i++;
		}
	}
}

void	ft_print(int x, int y, int z)
{
	ft_putchar(',');
	ft_putchar(' ');
	ft_putchar(x);
	ft_putchar(y);
	ft_putchar(z);
}
