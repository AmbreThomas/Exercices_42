/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/06 19:10:47 by athomas           #+#    #+#             */
/*   Updated: 2016/07/07 20:31:02 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int		ft_putchar(char c);
void	ft_print_comb2(void);
int		ft_lol(int a, int b, int c, int d);
void	ft_print_nb(int a, int b, int c, int d);

int ft_putchar(char c)
{
	write(1, &c, 1);
	return (0);
}

void	ft_print_comb2(void)
{
	int a;
	int b;
	int c;
	int d;

	a = 48;
	b = 48;
	c = 48;
	d = 49;
	ft_putchar(a);
	ft_putchar(b);
	ft_putchar(' ');
	ft_putchar(c);
	ft_putchar(d);
	while (1)
	{
		if (ft_lol(a, b, c, d) == 0)
			return ;
	}
}

int		ft_lol(int a, int b, int c, int d)
{
	a = 48;
	while (a <= 57)
	{
		b = 48;
		while (b <= 56)
		{
			c = a;
			while (c <= 57)
			{
				d = 48;
				while (d <= 57)
				{
					ft_print_nb(a, b, c, d);
					if (a == 57 && b == 56 && c == 57 && d == 57)
						return (0);
					d++;
				}
				c++;
			}
			b++;
		}
		a++;
	}
	return (1);
}

void	ft_print_nb(int a, int b, int c, int d)
{
	if (a == 48 && b == 48 && c == 48 && d == 49)
		return ;
	ft_putchar(',');
	ft_putchar(' ');
	ft_putchar(a);
	ft_putchar(b);
	ft_putchar(' ');
	ft_putchar(c);
	ft_putchar(d);
}

int		main(void)
{
	ft_print_comb2();
	return (0);
}
