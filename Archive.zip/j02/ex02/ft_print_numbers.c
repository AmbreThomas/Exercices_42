/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_numbers.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/06 16:18:36 by athomas           #+#    #+#             */
/*   Updated: 2016/07/06 19:15:08 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int		ft_putchar(char c);
void	ft_print_numbers(void);

void	ft_print_numbers(void)
{
	int i;

	i = 48;
	while (i < 58)
	{
		ft_putchar(i);
		i++;
	}
}
