/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_alphabet.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/06 10:19:31 by athomas           #+#    #+#             */
/*   Updated: 2016/07/07 09:41:47 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int		ft_putchar(char c);
void	ft_print_alphabet(void);

void	ft_print_alphabet(void)
{
	int i;

	i = 97;
	while (i < 123)
	{
		ft_putchar(i);
		i++;
	}
}
