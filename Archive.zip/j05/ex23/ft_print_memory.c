/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_memory.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/12 19:03:47 by athomas           #+#    #+#             */
/*   Updated: 2016/07/12 19:09:36 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int		ft_putchar(char c);

int		ft_putchar(char c)
{
	write(1, &c, 1);
	return (0);
}

void	*ft_print_memory(void *addr, unsigned int size)
{
	if (size == 0)
		return ;
	while (size > 0)
	{
	}
	return (addr);
}

int		main(void)
{
	void *ptr;
	int a;
	unsigned int taille;

	a = 12;
	ptr = &a;
	taille = 2;
	ft_print_memory(ptr, taille);
	return (0);
}
