/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi_base.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/12 17:24:23 by athomas           #+#    #+#             */
/*   Updated: 2016/07/12 18:15:36 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_recursive_power(int nb, int power)
{
	if (power < 0)
		return (0);
	if (power == 0)
		return (1);
	else
		return (nb * ft_recursive_power(nb, power - 1));
	return (0);
}

int		ft_strlen(char *str)
{
	int		i;
	char	temp;

	i = 0;
	temp = str[i];
	while (temp)
	{
		i++;
		temp = str[i];
	}
	return (i);
}

int		check_error_base(char *base)
{
	int		i;
	int		j;
	char	temp;

	i = 0;
	if (ft_strlen(base) <= 1)
		return (0);
	while (base[i])
	{
		j = i + 1;
		temp = base[i];
		while (base[j])
		{
			if (base[j] == temp)
				return (0);
			j++;
		}
		if (base[i] == '+' || base[i] == '-')
			return (0);
		i++;
	}
	return (1);
}

int		convert(char nb, char *base, int puissance)
{
	int i;
	int temp;

	i = 0;
	while (base[i])
	{
		if (base[i] == nb)
			temp = i;
		i++;
	}
	printf("%d \n", temp);
	return (temp * ft_recursive_power(ft_strlen(base), puissance));
}

int		ft_atoi_base(char *str, char *base)
{
	int signe;
	int result;
	int i;

	if (check_error_base(base) == 0)
		return (0);
	signe = 1;
	i = 0;
	result = 0;
	while (*str == ' ' || *str == '\t' || *str == '\n' || *str == '\v'
					|| *str == '\f' || *str == '\r')
		str++;
	if (str[i] == '-')
		signe = -1;
	if (str[i] == '-' || str[i] == '+')
		i++;
	while (str[i])
	{
		result += convert(str[i], base, ft_strlen(str) - i - 1);
		i++;
	}
	return (result * signe);
}
