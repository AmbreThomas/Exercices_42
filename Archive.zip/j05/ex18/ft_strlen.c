/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/07 19:27:48 by athomas           #+#    #+#             */
/*   Updated: 2016/07/12 15:47:11 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int		ft_strlen(char *str);

int		ft_strlen(char *str)
{
	int		i;
	char	temp;

	i = 0;
	temp = str[i];
	while (temp)
	{
		i++;
		temp = str[i];
	}
	return (i);
}
