/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/11 17:49:05 by athomas           #+#    #+#             */
/*   Updated: 2016/07/13 16:46:05 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int				ft_strlen(char *str)
{
	int		i;
	char	temp;

	i = 0;
	temp = str[i];
	while (temp)
	{
		i++;
		temp = str[i];
	}
	return (i);
}

unsigned int	ft_strlcat(char *dest, char *src, unsigned int nb)
{
	unsigned int i;
	unsigned int j;
	unsigned int temp;

	i = 0;
	while (dest[i] && i < nb)
		i++;
	j = 0;
	temp = i;
	while (src[j] && i < nb - 1)
	{
		dest[i] = src[j];
		i++;
		j++;
	}
	if (temp < nb)
		dest[i] = '\0';
	return (temp + ft_strlen(src));
}
