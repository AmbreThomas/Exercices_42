/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/11 10:05:14 by athomas           #+#    #+#             */
/*   Updated: 2016/07/12 18:29:41 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_putchar(char c);

int		ft_strlen(char *str)
{
	int		i;
	char	temp;

	i = 0;
	temp = str[i];
	while (temp)
	{
		i++;
		temp = str[i];
	}
	return (i);
}

void	ft_putstr(char *str)
{
	int		i;
	char	temp;

	i = 0;
	temp = str[i];
	while (temp)
	{
		ft_putchar(temp);
		i++;
		temp = str[i];
	}
}

int		check_error_base(char *base)
{
	int		i;
	int		j;
	char	temp;

	i = 0;
	if (ft_strlen(base) <= 1)
		return (0);
	while (base[i])
	{
		j = i + 1;
		temp = base[i];
		while (base[j])
		{
			if (base[j] == temp)
				return (0);
			j++;
		}
		if (base[i] == '+' || base[i] == '-')
			return (0);
		i++;
	}
	return (1);
}

void	ft_putnbr_base(int nbr, char *base)
{
	if (check_error_base(base) == 0)
		return ;
	if (nbr < 0)
	{
		ft_putchar('-');
		nbr = nbr * -1;
	}
	if (nbr / ft_strlen(base) != 0)
	{
		ft_putnbr_base(nbr / ft_strlen(base), base);
	}
	ft_putchar(base[nbr % ft_strlen(base)]);
}
