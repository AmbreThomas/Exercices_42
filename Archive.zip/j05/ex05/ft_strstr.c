/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/11 12:25:10 by athomas           #+#    #+#             */
/*   Updated: 2016/07/12 10:30:10 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_strlen(char *str)
{
	int		i;
	char	temp;

	i = 0;
	temp = str[i];
	while (temp)
	{
		i++;
		temp = str[i];
	}
	return (i);
}

char	*ft_strstr(char *str, char *to_find)
{
	int i;
	int compteur;

	i = 0;
	while (i < ft_strlen(str) - ft_strlen(to_find) + 1)
	{
		compteur = 0;
		if (str[i] == to_find[compteur])
		{
			while (compteur < ft_strlen(to_find) &&
					str[i + compteur] == to_find[compteur])
			{
				compteur++;
				if (compteur == ft_strlen(to_find) - 1)
					return (&str[i]);
			}
		}
		i++;
	}
	return (0);
}
