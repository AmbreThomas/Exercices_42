/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/12 10:32:34 by athomas           #+#    #+#             */
/*   Updated: 2016/07/12 10:38:45 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

int ft_strcmp(char *s1, char *s2);

int		main(void)
{
	printf("%i \n", ft_strcmp("abce", "abme"));
	printf("%i \n", strcmp("abce", "abme"));
	return (0);
}
