/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/11 15:50:52 by athomas           #+#    #+#             */
/*   Updated: 2016/07/11 16:23:48 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_strlen(char *str)
{
	int		i;
	char	temp;

	i = 0;
	temp = str[i];
	while (temp)
	{
		i++;
		temp = str[i];
	}
	return (i);
}

char	*ft_strcat(char *dest, char *src)
{
	int i;
	int compteur;

	compteur = 0;
	i = ft_strlen(dest);
	while (compteur < ft_strlen(src))
	{
		dest[i] = src[compteur];
		compteur++;
		i++;
	}
	return (dest);
}
