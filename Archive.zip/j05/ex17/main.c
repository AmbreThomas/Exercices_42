/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/12 13:46:16 by athomas           #+#    #+#             */
/*   Updated: 2016/07/12 13:48:17 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char *ft_strncat(char *dest, char *src, int nb);

int		main(void)
{
	char dest[] = "yo";
	char src[] = "salute";
	int nb = 3;

	printf("%s", ft_strncat(dest, src, nb));
	return (0);
}
