/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/12 13:42:15 by athomas           #+#    #+#             */
/*   Updated: 2016/07/12 13:43:43 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char *ft_strcat(char *dest, char *src);

int		main(void)
{
	char dest[] = "yo";
	char src[] = "salute";
	printf("%s", ft_strcat(dest, src));
	return (0);
}
