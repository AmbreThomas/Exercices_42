/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/12 10:39:59 by athomas           #+#    #+#             */
/*   Updated: 2016/07/12 10:41:15 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

int ft_strncmp(char *s1, char *s2, unsigned int n);

int		main(void)
{
	printf("%i", ft_strncmp("abcdef", "abmce", 4));
	printf("%i", strncmp("abcdef", "abmce", 4));
}
