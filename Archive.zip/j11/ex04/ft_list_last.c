/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_last.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/19 13:56:13 by athomas           #+#    #+#             */
/*   Updated: 2016/07/20 04:17:26 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"

t_list	*ft_list_last(t_list *begin_list)
{
	if (begin_list->next)
	{
		while (begin_list->next)
		{
			begin_list = begin_list->next;
		}
		return (begin_list);
	}
	else
		return (begin_list);
}
