/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/19 15:15:06 by athomas           #+#    #+#             */
/*   Updated: 2016/07/20 04:08:06 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"
#include <stdlib.h>
#include <stdio.h>

t_list *ft_list_last(t_list *begin_list);
t_list *ft_create_elem(void *data);
void ft_list_push_back(t_list **begin_list, void *data);

void	afficherliste(t_list *liste)
{
	while (liste)
	{
		if (liste->next == NULL)
		{
			printf("%s\n", liste->data);
			return ;
		}
		else
		{
			while (liste)
			{
				printf("%s\n", liste->data);
				liste = liste->next;
			}
		}
	}
}

int main(void)
{
	t_list *maListe = ft_create_elem("salut");

	printf("%c\n", '-');
	afficherliste(maListe);
	ft_list_push_back(&maListe, "yo");
	printf("%s\n", "--");
	afficherliste(maListe);
	ft_list_push_back(&maListe, "ca va?");
	printf("%s\n", "---");
	afficherliste(maListe);
	printf("%s\n", ft_list_last(maListe)->data);
	return 0;
}
