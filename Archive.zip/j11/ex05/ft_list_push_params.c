/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_push_params.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/19 14:13:15 by athomas           #+#    #+#             */
/*   Updated: 2016/07/20 04:28:55 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"

t_list	*ft_list_push_params(int ac, char **av)
{
	t_list	*liste;
	int		i;
	t_list	*tmp;

	i = 1;
	if (ac > 1)
	{
		liste = ft_create_elem(av[i++]);
		while (i < ac)
		{
			tmp = ft_create_elem(av[i++]);
			tmp->next = liste;
			liste = tmp;
		}
	}
	else
		return (0);
	return (liste);
}
