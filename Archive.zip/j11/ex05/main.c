/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/19 15:15:06 by athomas           #+#    #+#             */
/*   Updated: 2016/07/20 04:29:07 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"
#include <stdlib.h>
#include <stdio.h>

t_list *ft_list_push_params(int ac, char **av);
t_list *ft_create_elem(void *data);

void	afficherliste(t_list *liste)
{
	while (liste)
	{
		if (liste->next == NULL)
		{
			printf("%s\n", liste->data);
			return ;
		}
		else
		{
			while (liste)
			{
				printf("%s\n", liste->data);
				liste = liste->next;
			}
		}
	}
}

int main(int ac, char **av)
{
	t_list *maListe;
	maListe = ft_list_push_params(ac, av);
	afficherliste(maListe);
	return (0);
}
