/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/19 15:15:06 by athomas           #+#    #+#             */
/*   Updated: 2016/07/20 05:32:22 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"
#include <stdlib.h>
#include <stdio.h>

t_list *ft_list_at(t_list *begin_list, unsigned int nbr);
t_list *ft_create_elem(void *data);
void ft_list_push_front(t_list **begin_list, void *data);

void	afficherliste(t_list *liste)
{
	while (liste)
	{
		if (liste->next == NULL)
		{
			printf("%s\n", liste->data);
			return ;
		}
		else
		{
			while (liste)
			{
				printf("%s\n", liste->data);
				liste = liste->next;
			}
		}
	}
}

int main(void)
{
	t_list *maListe = ft_create_elem("salut");

	printf("%c\n", '-');
	afficherliste(maListe);
	ft_list_push_front(&maListe, "yo");
	printf("%s\n", "--");
	afficherliste(maListe);
	ft_list_push_front(&maListe, "ca va?");
	printf("%s\n", "---");
	afficherliste(maListe);
	printf("TEST\n");
	afficherliste(ft_list_at(maListe, 2));
	return 0;
}
