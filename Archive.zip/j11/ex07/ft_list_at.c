/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_at.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/20 05:07:28 by athomas           #+#    #+#             */
/*   Updated: 2016/07/20 05:32:41 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"

t_list	*ft_list_at(t_list *begin_list, unsigned int nbr)
{
	t_list	*tmp;
	int		i;

	i = 1;
	if (begin_list->next)
	{
		while (begin_list->next)
		{
			if (i == nbr)
			{
				tmp = begin_list;
				tmp->next = 0;
				return (tmp);
			}
			begin_list = begin_list->next;
			i++;
		}
	}
	else
		return (0);
	return (0);
}
