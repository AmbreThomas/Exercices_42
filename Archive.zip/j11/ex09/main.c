/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/19 15:15:06 by athomas           #+#    #+#             */
/*   Updated: 2016/07/20 08:29:20 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"
#include <stdlib.h>
#include <stdio.h>

void ft_list_foreach(t_list *begin_list, void (*f)(void *));
void ft_list_clear(t_list **begin_list);
t_list *ft_create_elem(void *data);
void ft_list_push_front(t_list **begin_list, void *data);

void	afficherliste(t_list *liste)
{
	while (liste)
	{
		if (liste->next == NULL)
		{
			printf("%s\n", liste->data);
			return ;
		}
		else
		{
			while (liste)
			{
				printf("%s\n", liste->data);
				liste = liste->next;
			}
		}
	}
}

void	hello(void *truc)
{
	truc = "hello";
}

int main(void)
{
	t_list *maListe = ft_create_elem("salut");

	printf("%c\n", '-');
	afficherliste(maListe);
	ft_list_push_front(&maListe, "yo");
	printf("%s\n", "--");
	afficherliste(maListe);
	ft_list_push_front(&maListe, "ca va?");
	printf("%s\n", "---");
	afficherliste(maListe);
	ft_list_foreach(maListe, &hello);
	afficherliste(maListe);
	return 0;
}
