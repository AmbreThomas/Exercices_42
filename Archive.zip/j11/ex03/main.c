/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/19 15:15:06 by athomas           #+#    #+#             */
/*   Updated: 2016/07/20 03:31:31 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"
#include <stdlib.h>
#include <stdio.h>

int ft_list_size(t_list *begin_list);
t_list *ft_create_elem(void *data);
void ft_list_push_front(t_list **begin_list, void *data);

void	afficherliste(t_list *liste)
{
	while (liste)
	{
		if (liste->next == NULL)
		{
			printf("%s\n", liste->data);
			return ;
		}
		else
		{
			while (liste)
			{
				printf("%s\n", liste->data);
				liste = liste->next;
			}
		}
	}
}

int main(void)
{
	t_list *maListe = ft_create_elem("salut");

	printf("%c\n", '-');
	printf("Taille : %i\n", ft_list_size(maListe));
	afficherliste(maListe);
	ft_list_push_front(&maListe, "yo");
	printf("%s\n", "--");
	printf("Taille : %i\n", ft_list_size(maListe));
	afficherliste(maListe);
	ft_list_push_front(&maListe, "ca va?");
	printf("%s\n", "---");
	printf("Taille : %i\n", ft_list_size(maListe));
	afficherliste(maListe);
	return 0;
}
