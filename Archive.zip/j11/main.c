/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/19 15:15:06 by athomas           #+#    #+#             */
/*   Updated: 2016/07/20 02:44:07 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"
#include <stdlib.h>
#include <stdio.h>

void ft_list_push_back(t_list **begin_list, void *data);

void	afficherliste(t_list *liste)
{
	while (liste)
	{
		if (liste->next == NULL)
		{
			printf("%s\n", liste->data);
			return ;
		}
		else
		{
			while (liste)
			{
				printf("%s\n", liste->data);
				liste = liste->next;
			}
		}
	}
}

int main(void)
{
	t_list *maListe = ft_create_elem("salut");

	printf("%c\n", '-');
	afficherliste(maListe);
	ft_list_push_back(&maListe, "yo");
	printf("%s\n", "--");
	afficherliste(maListe);
	ft_list_push_back(&maListe, "ca va?");
	printf("%s\n", "---");
	afficherliste(maListe);
	return 0;
}
