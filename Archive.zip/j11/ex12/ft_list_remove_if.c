/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_remove_if.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/20 08:39:23 by athomas           #+#    #+#             */
/*   Updated: 2016/07/20 08:50:20 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"

void	ft_list_remove_if(t_list **begin_list, void *data_ref, int (*cmp)())
{
	while (*begin_list)
	{
		if (cmp((*begin_list)->data, data_ref) == 0)
		{
			free(*begin_list);
		}
		(*begin_list) = (*begin_list)->next;
	}
}
