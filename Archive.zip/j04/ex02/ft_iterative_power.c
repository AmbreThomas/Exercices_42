/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/08 14:36:05 by athomas           #+#    #+#             */
/*   Updated: 2016/07/09 12:32:24 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int ft_iterative_power(int nb, int power);

int		ft_iterative_power(int nb, int power)
{
	int temp;

	temp = nb;
	if (power < 0)
		return (0);
	if (power == 0)
		return (1);
	power--;
	while (power > 0)
	{
		nb *= temp;
		power--;
	}
	return (nb);
}
