/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_prime.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/09 10:04:05 by athomas           #+#    #+#             */
/*   Updated: 2016/07/09 14:27:06 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int		ft_return_sqrt(int nb)
{
	int i;

	i = 1;
	while (i < nb / 2)
	{
		if ((i * i) == nb)
			return (i);
		i++;
	}
	return (i);
}

int		ft_is_prime(int nb)
{
	int racine;
	int i;

	racine = ft_return_sqrt(nb) - 1;
	if (nb <= 0 || nb == 1)
		return (0);
	if (nb == 2)
		return (1);
	if (nb % 2 == 0)
		return (0);
	i = 3;
	while (i < nb)
	{
		if (nb % i == 0)
			return (0);
		i += 2;
	}
	return (1);
}
