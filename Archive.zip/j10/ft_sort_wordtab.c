/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_wordtab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/18 13:15:00 by athomas           #+#    #+#             */
/*   Updated: 2016/07/18 14:01:21 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

int		ft_strcmp(char *s1, char *s2)
{
	int i;

	i = 0;
	while(s1[i] || s2[i])
	{
		if (s1[i] < s2[i] || s1[i] > s2[i])
			return (s1[i] - s2[i]);
		i++;
	}
	return (0);
}

void	ft_str_swap(char **tab, int i, int j)
{
	char *temp;

	temp	= tab[i];
	tab[i] = tab[j];
	tab[j] = temp;
}

char	**ft_str_sort(int n, char **tab)
{
	int flag;
	int i;
	int compteur;

	flag = 1;
	while (flag)
	{
		i = 0;
		compteur = 0;
		while (i < n - 1)
		{
			if (ft_strcmp(tab[i], tab[i + 1]) > 0)
			{
				compteur += 1;
				ft_str_swap(tab, i, i + 1);
			}
			i++;
		}
		if (compteur == 0)
			flag = 0;
	}
	return (tab);
}

void ft_sort_wordtab(char **tab)
{
	int i;

	i = 0;
	while(tab[i])
		i++;
	ft_str_sort(i, tab);
}


int     ft_isspace(char c)
{
	if (c == ' ' || c == '\t' || c == '\n')
		return (1);
	return (0);
}

int     ft_calc_str(char *str)
{
	int i;
	int mot;

	mot = 0;
	i = 0;
	while (str[i])
	{
	while (ft_isspace(str[i]))
		i++;
	if (str[i])
		mot++;
	while (str[i] && (str[i] != ' ' && str[i] != '\t' && str[i] != '\n'))
		i++;
	}
	return (mot);
}

int     ft_let(char *str, int i)
{
	int len;

	len = 0;
	while (str[i] && (str[i] != ' ' && str[i] != '\t' && str[i] != '\n'))
	{
		len++;
		i++;
	}
	return (len);
}

char    **ft_split_whitespaces(char *str)
{
	int     i;
	int     j;
	int     k;
	char    **tab;

	i = 0;
	j = 0;
	if (!(tab = (char **)malloc(sizeof(char *) * (ft_calc_str(str) + 1))))
		return (NULL);
	while (str[i])
	{
		while (str[i] && ((str[i] == ' ' || str[i] == '\t' || str[i] == '\n')))
			i++;
		if (str[i])
		{
			if (!(tab[j] = (char*)malloc(sizeof(char) * (ft_let(str, i) + 1))))
				return (NULL);
		k = 0;
		while (str[i] && str[i] != ' ' && str[i] != '\t' && str[i] != '\n')
			tab[j][k++] = str[i++];
		tab[j++][k] = '\0';
		}
	}
	tab[j] = 0;
	return (tab);
}

int		main()
{
	char **tab;
	tab = ft_split_whitespaces("  Allo ahbdi bdiohg cd d DD Z z 18 ueiwhg 54");
	int i = 0;
	ft_sort_wordtab(tab);
	while (tab[i])
	{
		printf("%s\n", tab[i]);
		i++;
	}
	return (0);
}
