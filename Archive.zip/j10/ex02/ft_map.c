/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_map.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/18 09:47:09 by athomas           #+#    #+#             */
/*   Updated: 2016/07/18 09:56:43 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		*ft_map(int *tab, int length, int (*f)(int))
{
	int *retour;
	int i;

	i = 0;
	retour = (int*)malloc(sizeof(int) * length);
	while (i < length)
	{
		retour[i] = f(tab[i]);
		i++;
	}
	return (retour);
}
