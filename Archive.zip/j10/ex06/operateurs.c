/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operateurs.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/18 10:24:47 by athomas           #+#    #+#             */
/*   Updated: 2016/07/18 10:27:15 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		addition(int a, int b)
{
	return (a + b);
}

int		soustraction(int a, int b)
{
	return (a - b);
}

int		division(int a, int b)
{
	return (a / b);
}

int		multiplication(int a, int b)
{
	return (a * b);
}

int		modulo(int a, int b)
{
	return (a % b);
}
