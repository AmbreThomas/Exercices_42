/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/18 10:22:52 by athomas           #+#    #+#             */
/*   Updated: 2016/07/19 15:56:12 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "inclusions.h"

int		check_stop(char c, int b)
{
	if (c == '/' && b == 0)
	{
		ft_putstr("Stop : division by zero");
		return (0);
	}
	else if (c == '%' && b == 0)
	{
		ft_putstr("Stop : modulo by zero");
		return (0);
	}
	return (1);
}

void	make_operation(int a, int b, char operateur, char *ope)
{
	int		i;
	int		(*tab[5]) ();

	tab[0] = &multiplication;
	tab[1] = &soustraction;
	tab[2] = &division;
	tab[3] = &addition;
	tab[4] = &modulo;
	i = 0;
	if (check_stop(operateur, b) == 0)
		return ;
	while (i < 5)
	{
		if (operateur == ope[i])
		{
			ft_putnbr(tab[i++](a, b));
			return ;
		}
		i++;
	}
	ft_putchar('0');
}

int		ft_atoi(char *str)
{
	int signe;
	int result;
	int i;

	signe = 1;
	result = 0;
	i = 0;
	while (str[i] == ' ' || str[i] == '\t' || str[i] == '\n' || str[i] == '\v'
			|| str[i] == '\f' || str[i] == '\r')
		i++;
	if (str[i] == '-')
		signe = -1;
	if (str[i] == '-' || str[i] == '+')
		i++;
	while (str[i] <= '9' && str[i] >= '0')
	{
		result = result * 10 + str[i] - '0';
		i++;
	}
	return (result * signe);
}

int		main(int ac, char **av)
{
	int a;
	int b;

	if (ac != 4)
		return (0);
	a = ft_atoi(av[1]);
	b = ft_atoi(av[3]);
	if (a == 0 && av[1][0] != '0')
		ft_putnbr(b);
	else if (b == 0 && av[3][0] != '0')
		ft_putnbr(a);
	else if ((b == 0 && av[3][0] != '0') && (a == 0 && av[1][0] != '0'))
		ft_putchar('0');
	else
		make_operation(a, b, av[2][0], "*-/+%");
	ft_putchar('\n');
	return (0);
}
