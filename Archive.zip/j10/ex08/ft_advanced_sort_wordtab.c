/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_advanced_sort_wordtab.c                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/18 14:04:33 by athomas           #+#    #+#             */
/*   Updated: 2016/07/18 23:49:13 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_str_swap(char **tab, int i, int j)
{
	char *temp;

	temp = tab[i];
	tab[i] = tab[j];
	tab[j] = temp;
}

char	**ft_str_sort(int n, char **tab, int (*cmp)(char *, char *))
{
	int flag;
	int i;
	int compteur;

	flag = 1;
	while (flag)
	{
		i = 0;
		compteur = 0;
		while (i < n - 1)
		{
			if (cmp(tab[i], tab[i + 1]) > 0)
			{
				compteur += 1;
				ft_str_swap(tab, i, i + 1);
			}
			i++;
		}
		if (compteur == 0)
			flag = 0;
	}
	return (tab);
}

void	ft_advanced_sort_wordtab(char **tab, int (*cmp)(char *, char *))
{
	int i;

	i = 0;
	while (tab[i])
		i++;
	ft_str_sort(i, tab, cmp);
}
