/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   inclusions.h                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: athomas <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/18 11:06:03 by athomas           #+#    #+#             */
/*   Updated: 2016/07/18 13:09:38 by athomas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef INCLUSIONS_H
# define INCLUSIONS_H

void			ft_putchar(char c);
int				addition(int a, int b);
int				soustraction(int a, int b);
int				modulo(int a, int b);
int				division(int a, int b);
int				multiplication(int a, int b);
void			ft_putnbr(int nb);
void			ft_putstr(char *str);
//typedef int	(*fptr)(int, int);

#endif
